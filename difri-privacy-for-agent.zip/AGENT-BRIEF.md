# Бриф для агента: DiFri Privacy — текущее состояние и нерешённая проблема

## Что это
DiFri Privacy v2.1.0 — приватный браузер на **Tauri 2.12.5** (Rust 1.99.1 MSVC + vanilla JS/Vite, WebView2).
Исходник: архив с рабочего стола (`C:\Users\New\Desktop\1\workspace-01a1cf35-...zip`) + пользовательский патч
(`difri-privacy-features.patch`) + исправления агента AutoClaw (список ниже).

## Окружение сборки (всё уже установлено)
- Windows 10 22H2, CPU Celeron J1900 (медленный — сборка ~15 мин), 16 GB RAM, **без прав администратора**.
- Rust: `E:\rust` (RUSTUP_HOME/CARGO_HOME), тулчейн stable-x86_64-pc-windows-msvc 1.99.1.
- MSVC: `E:\VS2022BuildTools` (vcvars не нужен — INCLUDE/LIB прописаны в `E:\difri-build\env.ps1`), Windows SDK 10.0.26100 на C:.
- Node 24, npm. NSIS уже распакован: `%LOCALAPPDATA%\tauri\NSIS` (bundler сам не скачивал — DNS-сбой, положено вручную, SHA1 сверены).
- **Сборка:** `powershell -File E:\difri-build\build-windows.ps1` → установщик в `E:\difri-build\out\`.
  Эквивалент: `cd E:\difri-build\difri-privacy; npm run tauri:build` после дот-сорса `E:\difri-build\env.ps1`.
- **Установка тихо:** `"DiFri Privacy_2.1.0_x64-setup.exe" /S` (per-user, в `%LOCALAPPDATA%\DiFri Privacy`).

## Что уже исправлено (не повторять)
1. Cargo.toml: убраны несуществующие features v1 (`dialog-all` и пр.) и фантомный крейт `tauri-plugin-android`;
   `crate-type` +`rlib`; tauri 2.12; плагины "2"; reqwest на rustls; LTO thin (полная — часы на этом CPU).
2. tauri.conf.json: `frontendDist: "gen/dist"` (vite пишет в `src-tauri/gen/dist`); убраны v1-ключи `useTauriBuild`,
   top-level `permissions`, `plugins{}`; категория "Utilities" (не "Network"); `url: "app.html"`; **CSP удалён полностью**
   (он блокировал инлайн-стили — панель загрузок разворачивалась текстом).
3. Добавлен отсутствовавший `src-tauri/build.rs` (`tauri_build::build()`) — без него `generate_context!` падает (OUT_DIR).
4. `main.rs`: `#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]` перенесён сюда из lib.rs
   (в lib.rs не действует → выскакивало консольное окно = «второе окно» у пользователя).
5. Мульти-вебвью (из патча) **удалено полностью**: на Windows wry делает дочерние вебвью отдельными плавающими окнами
   (это и было «второе нерабочее окно»). Модель теперь — одиночный вебвью (как в оригинале v2.1.0):
   `navigate_tab` навигирует текущий вебвью и инъектит content-script; вкладки — записи в localStorage;
   на сайтах content-script рисует свою мини-панель, кнопка «Новая вкладка» возвращает на `app.html`.
6. lib.rs: `evaluate_script` не существует в tauri 2.12 → `eval`/`eval_with_callback`; `navigate(Url)` принимает
   `tauri::Url` (не &str); enum DownloadStatus — юнит-варианты + поле `error`; загрузчик на `resp.chunk()`;
   статистика блокировок — `static PAGE_STATS: Mutex<String>`, снимок через отложенный eval через 4 с после навигации.
7. app.html: убран случайный CSS-комментарий `/* Менеджер загрузок */` из тела HTML; добавлен `saveTabs()`;
   вкладки в localStorage (`difri:tabs`, `difri:activeTab`); кнопка «Назад» переключает на предыдущую вкладку.

## ТЕКУЩАЯ НЕРАШЕННАЯ ПРОБЛЕМА
**Симптом:** приложение устанавливается и запускается, окно одно, тулбар app.html отрисовывается (CSS работает),
но область контента (#stage) — чёрная; ввод `facebook.com` + Enter **не приводит к видимой навигации**
(контент остаётся чёрным, заголовок окна не меняется). Тосты с ошибками не успели поймать (живут 2.2 с).

**Что уже проверено:**
- `node --check` JS-блока app.html — синтаксис валиден (была сломана вставкой диагностики — исправлено, теперь чисто).
- Дамп окон (`dump-windows.ps1`, PID передать аргументом): `Tauri Window` → child `WRY_WEBVIEW` (86,92)-(1286,892)
  + `Chrome_WidgetWin_0` — структура и позиционирование вебвью корректные. Консоли больше нет.
- Тот же `gen/dist/app.html` в обычном браузере (file://) рендерится и работает корректно — HTML/CSS в порядке.
- Инсталлятор собран из текущего исходника: `out/DiFri Privacy_2.1.0_x64-setup.exe` (совпадает с src).

**Рабочие гипотезы (проверять в этом порядке):**
1. **invoke("navigate_tab") не доходит до Rust или падает в нём.** В release нет devtools. Быстрый способ увидеть ошибки:
   - собрать debug: `cargo run` из `src-tauri` (запустится с консолью; `eprintln!` в начале `navigate_tab` видны);
   - или добавить фичу `devtools` к tauri (`tauri = { version = "2.12", features = ["devtools"] }`) → Ctrl+Shift+I.
2. **`eval_with_callback` + `recv_timeout(5с)` в `navigate_tab`** — если колбэк не приходит (страница грузится),
   команда вернёт Err через 5 с (сам navigate к этому моменту уже выполнен, но JS упадёт в catch и не обновит UI).
   Попробовать заменить на fire-and-forget `webview.eval(script)` без ожидания.
3. **WebView2/GPU на J1900:** чёрный контент при работающем тулбаре может быть проблемой рендеринга.
   Тест: `$env:WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS='--disable-gpu'` перед запуском exe.
4. **content-script.js (~35 КБ) инъектится при каждой навигации** — если он кидает исключение на странице,
   это может ломать отрисовку. Проверить навигацию без инъекции (закомментировать eval в navigate_tab).
5. `state.filterRulesJson` в JS — убеждаться, что не undefined к моменту invoke (должен грузиться fetch'ем
   `./filter-rules.json` — проверять сетевую вкладку devtools).

**Критерий готовности:** ввод facebook.com + Enter показывает facebook в том же окне; на сайте видна мини-панель
content-script (Назад/Вперёд/Новая вкладка/счётчик блокировок); «Новая вкладка» возвращает на app.html.

## Файлы
- `src/` — исходники (эквивалент `E:\difri-build\difri-privacy` и workspace-копии); `src-tauri/src/lib.rs` — ядро.
- `installer/` — последний установщик (собран из этого же исходника).
- `scripts/` — UIA-скрипты тестирования: `dump-windows.ps1 <pid>` (дамп окон), `uia.ps1` (скриншот/клик/ввод),
  `test-nav3.ps1` (тест навигации для PID 8684 — поправить PID).
- `shots/` — скриншоты состояния (v2_nav.png — чёрный контент после ввода facebook.com).
- Лог сборки Windows и все `fix*.ps1` — история правок (в корне E:\difri-build, не включены в архив).
